<?php

class Meow_MWCODE_API
{
  private $core = null;
  private $snippet = null;


  public function __construct( $core, $snippet ) {
		$this->core = $core;
    $this->snippet = $snippet;
	}

  /**
   * Get a function by its ID.
   * 
   * The options are used to filter the functions:
   * - 'php_ready_args' (bool): If false, the arguments will not be formatted for PHP. (no $ before the names).
   *
   * @param $id
   * @param array $options
   *
   * @return mixed
   */
  public function get_function( $id, $options = [] ) {
    $snippet = $this->snippet->get_function( $id, $options );
    return $snippet;
  }


  /**
   * Get a function by its name.
   * 
   * The options are used to filter the functions:
   * - 'php_ready_args' (bool): If false, the arguments will not be formatted for PHP. (no $ before the names).
   *
   * @param $name The name of the function to be retrieved.
   * @param array $options
   *
   * @return mixed
   */
  public function get_function_by_name( $name, $options = [] ) {
    $snippet = $this->snippet->get_function_by_name( $name, $options );
    return $snippet;
  }

  /**
   * Get all functions.
   * 
   * @return mixed 
   * 
   */
  public function get_functions( $safe = true ) {
    $snippets = $this->snippet->get_functions();

    if ( $safe ) {

      $snippets = array_filter( $snippets, function( $snippet ) {
        $name = $snippet['name'];
        if ( !preg_match( '/^[a-zA-Z0-9_-]{1,64}$/', $name ) ) {
          return false;
        }

        return true;
      } );
      
    }

    return $snippets;
  }


  /**
   * Execute a function by its ID.
   * The arguments should be an associative array with the argument names as keys.
   * Example: [ "$city" => " 'Tokyo' ", "$date" => "1999" ]
   *
   * @param $id
   * @param $args
   *
   * @return mixed
   */
  public function execute_function( $id, $args ) {
    $output = $this->core->run_snippet( $id, $args );
    return $output;
  }


  /**
   * Create a new callable snippet ( Function ).
   *
   * @param string $name Name of the function. This should be the name of the function declaration, like 'get_weather'.
   * @param string $target Target of the snippet. This should be either 'php' or 'js'. This will be used to determine the type of the function.
   * @param string $code Code of the snippet. This should be either a PHP or a JS function. No code outside of the function itself should be included.
   * @param string $description Description of the snippet. This will be displayed in Code Engine and used for Function Calling.
   * @param array $args Arguments of the function. This array should have the full name of each argument, like ['$city', '$date']. The '$' is required if the function is PHP.
   * @param array $args_data Data of the arguments. This array should have the name of each argument as key and an array with the type, description and default value. Example: [ '$city' => ['type' => 'string', 'desc' => 'City name', 'default' => 'Tokyo' ] ]. This will be used for Function Calling.
   * @param string $behavior Behavior of the function. This should be either 'dynamic' or 'static'. This will be used for Function Calling.
   * 
   */
  public function create_function( $name, $target, $code, $description, $args, $args_data, $behavior ) {

    $temp_name = 'mwcode_' . time();

    $params = [
      // Predefined values
      'id'           => null,
      'active'       => 1,
      'priority'     => 10,
      'tags'         => ['api'],
      'endpoint'     => '',
      'scope'        => 'function',

      // Custom values
      'name' => $name ?? $temp_name,
      'code' => $code ?? "function $temp_name() { return 'Hello World'; }",
      'description' => $description ?? '',

      'functionName' => $name ?? $temp_name,
      'functionTarget'   => $target ?? 'php',
      'functionArgs'     => $args ?? [],
      'functionArgsDict' => $args_data ?? [],
      'functionBehavior' => $behavior ?? 'dynamic',
    ];

    $res = $this->core->add_snippet( $params );

    return $res;
  }
  

  /**
   * Update a function by its name. If the function does not exist, it will return false. The parameters are the same as create_function, but except the name the rest are optional. If not specified, the current values will be used.
   *
   * @param string $name Name of the function. This should be the name of the function declaration, like 'get_weather'.
   * @param string $target Target of the snippet. This should be either 'php' or 'js'. This will be used to determine the type of the function.
   * @param string $code Code of the snippet. This should be either a PHP or a JS function. No code outside of the function itself should be included.
   * @param string $description Description of the snippet. This will be displayed in Code Engine and used for Function Calling.
   * @param array $args Arguments of the function. This array should have the full name of each argument, like ['$city', '$date']. The '$' is required if the function is PHP.
   * @param array $args_data Data of the arguments. This array should have the name of each argument as key and an array with the type, description and default value. Example: [ '$city' => ['type' => 'string', 'desc' => 'City name', 'default' => 'Tokyo' ] ]. This will be used for Function Calling.
   * @param string $behavior Behavior of the function. This should be either 'dynamic' or 'static'. This will be used for Function Calling.
   */
  public function update_function( $name, $target, $code, $description, $args, $args_data, $behavior ) {
    $snippet = $this->snippet->get_function_by_name( $name );
    if ( !$snippet ) { return false; }

    $params = [
      // Predefined values
      'id'           => $snippet['snippetId'],
      'active'       => 1,
      'priority'     => 10,
      'tags'         => ['api'],
      'endpoint'     => '',
      'scope'        => 'function',

      // Custom values
      'name' => $name ?? $snippet['name'],
      'code' => $code ?? $snippet['code'],
      'description' => $description ?? '',

      'functionName' => $name ?? $snippet['functionName'],
      'functionTarget'   => $target ?? $snippet['functionTarget'],
      'functionArgs'     => $args ?? $snippet['functionArgs'],
      'functionArgsDict' => $args_data ?? $snippet['functionArgsDict'],
      'functionBehavior' => $behavior ?? $snippet['functionBehavior'],
    ];


    $res = $this->core->add_snippet( $params );

    return $res;
  }

  /**
   * Delete a function by its ID.
   *
   * @param int $id Function ID
   * @return mixed
   */
  public function delete_function( $id ) {
    $params = [
      'id' => $id,
    ];

    $this->snippet->delete_function_snippet( $params );
    $result = $this->snippet->delete( $params );

    return $result;
  }

  /**
   * Delete a function by its name.
   *
   * @param string $name Function name
   * @return mixed
   */
  public function delete_function_by_name( $name ) {
    $snippet = $this->snippet->get_function_by_name( $name );
    if ( !$snippet ) { return false; }

    $params = [
      'id' => $snippet['snippetId'],
    ];

    $this->snippet->delete_function_snippet( $params );
    $result = $this->snippet->delete( $params );

    return $result;
  }

}
