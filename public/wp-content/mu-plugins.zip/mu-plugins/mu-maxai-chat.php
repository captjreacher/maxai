<?php
/**
 * Plugin Name: MAXAI – Chat Endpoint (KB-first, 4o-mini)
 * Version: 2.0.2
 */
if (!defined('ABSPATH')) exit;

function maxai_get($key, $fallback=null){
  if (defined($key) && constant($key)) return constant($key);
  $env = getenv($key); if (!empty($env)) return $env;
  $opt = get_option(strtolower($key)); if (!empty($opt)) return $opt;
  return $fallback;
}

add_action('rest_pre_serve_request', function($served){
  if (!headers_sent()){
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
  }
  return $served;
}, 10);

add_action('rest_api_init', function () {
  register_rest_route('maxai/v1','/chat',[
    'methods'=>'POST',
    'callback'=>'maxai_chat_handler',
    'permission_callback'=>'__return_true',
  ]);
});

function maxai_chat_handler(WP_REST_Request $req){
  ob_start(); // swallow stray echoes/notices

  $apiKey = maxai_get('OPENAI_API_KEY');
  if (!$apiKey) { ob_end_clean(); return new WP_REST_Response(['ok'=>false,'error'=>'missing_api_key'],500); }

  $params   = $req->get_json_params() ?: [];
  $userMsg  = isset($params['message']) ? sanitize_text_field($params['message']) : '';
  if ($userMsg===''){ ob_end_clean(); return new WP_REST_Response(['ok'=>false,'error'=>'missing_message'],400); }

  // Always prefer 4o-mini
  $MODEL_4O_MINI = 'gpt-4o-mini';

  $vsId = maxai_get('MAXAI_VECTOR_STORE_ID'); // set via wp-config/ENV/wp option

  // Guardrails for grounded answers
  $instructions = <<<SYS
You are the Maximised AI website assistant.
PRIORITY: Answer ONLY using passages retrieved from the knowledge base (file_search).
If nothing relevant is found, reply exactly: "I’m not sure from our FAQs." and offer Contact. Keep answers ≤120 words.
SYS;

  if ($vsId){
    // Responses API with file_search (grounded)
    $payload = [
      'model' => $MODEL_4O_MINI,
      'input' => [
        ['role'=>'system','content'=>$instructions],
        ['role'=>'user','content'=>$userMsg],
      ],
      'tools' => [[ 'type'=>'file_search', 'vector_store_ids'=>[$vsId] ]],
      'tool_choice' => 'auto',
    ];
    $endpoint = 'https://api.openai.com/v1/responses';
    $extract = function($json){
      if (!empty($json['output_text'])) return trim($json['output_text']);
      if (!empty($json['output']) && is_array($json['output'])){
        $t=''; foreach($json['output'] as $it){ if(!empty($it['content'])) foreach($it['content'] as $p){ if(!empty($p['text'])) $t.=$p['text']; } }
        return trim($t);
      }
      if (!empty($json['choices'][0]['message']['content'])) return (string)$json['choices'][0]['message']['content'];
      return '';
    };
  } else {
    // No KB available → classic Chat Completions (still 4o-mini)
    $payload = [
      'model' => $MODEL_4O_MINI,
      'messages' => [
        ['role'=>'system','content'=>'You are the Maximised AI website assistant. Be concise and helpful.'],
        ['role'=>'user','content'=>$userMsg],
      ],
      'temperature' => 0.7,
      'max_tokens'  => 400,
    ];
    $endpoint = 'https://api.openai.com/v1/chat/completions';
    $extract = function($json){
      return !empty($json['choices'][0]['message']['content']) ? (string)$json['choices'][0]['message']['content'] : '';
    };
  }

  $args = [
    'headers' => [
      'Authorization' => 'Bearer '.$apiKey,
      'Content-Type'  => 'application/json',
    ],
    'body'        => wp_json_encode($payload, JSON_UNESCAPED_UNICODE),
    'timeout'     => 30,
    'data_format' => 'body',
  ];

  $resp = wp_remote_post($endpoint, $args);
  ob_end_clean();

  if (is_wp_error($resp)){
    return new WP_REST_Response(['ok'=>false,'error'=>'upstream_request_failed','detail'=>$resp->get_error_message()],502);
  }

  $code = wp_remote_retrieve_response_code($resp);
  $body = wp_remote_retrieve_body($resp);
  $json = json_decode($body, true);
  $reply = is_array($json) ? $extract($json) : '';

  if ($code < 200 || $code >= 300 || $reply===''){
    return new WP_REST_Response([
      'ok'=>false,
      'error'=>'upstream_http_'.$code,
      'detail'=> is_string($body) ? mb_substr($body,0,1000) : 'Non-JSON upstream response'
    ], 502);
  }

  return new WP_REST_Response(['ok'=>true,'reply'=>$reply],200);
}
