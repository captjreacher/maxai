<?php
/**
 * Plugin Name: MAXAI – Chat Widget Loader (MU)
 * Version: 1.0.4
 */
if (!defined('ABSPATH')) exit;

add_action('wp_enqueue_scripts', function () {
    $handle  = 'maxai-chat';
    $js_path = WPMU_PLUGIN_DIR . '/maxai-chat.js';
    $js_url  = WPMU_PLUGIN_URL . '/maxai-chat.js';
    if (!file_exists($js_path)) return;

    // Find assets/chat-icon.webp (child theme first, then parent)
    $icon_url = '';
    foreach ([[get_stylesheet_directory(), get_stylesheet_directory_uri()],
              [get_template_directory(),   get_template_directory_uri()]] as [$dir, $uri]) {
        $p = trailingslashit($dir) . 'assets/chat-icon.webp';
        if (file_exists($p)) { $icon_url = trailingslashit($uri) . 'assets/chat-icon.webp?v=' . filemtime($p); break; }
    }
    if (!$icon_url) $icon_url = trailingslashit(get_stylesheet_directory_uri()) . 'assets/chat-icon.webp';

    wp_register_script($handle, $js_url, [], filemtime($js_path), true);

    // Pass config safely (survives minifiers/deferrers)
    wp_localize_script($handle, 'MAXAI_CHAT_CONFIG', [
        'ICON_URL' => $icon_url,
    ]);

    wp_enqueue_script($handle);
});
